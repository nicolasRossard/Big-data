package categorytest;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.apache.hadoop.mrunit.mapreduce.MapReduceDriver;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

import category.CategoryMapper;
import category.CategoryReducer;

public class TestCategory {
    MapReduceDriver<LongWritable, Text, Text, DoubleWritable, Text, DoubleWritable> mapReduceDriver;
    MapDriver<LongWritable, Text, Text, DoubleWritable> mapDriver;
    ReduceDriver<Text, DoubleWritable, Text, DoubleWritable> reduceDriver;

    @Before
    public void setUp() {
        /*
         * Initialize mapper/reducer/mapReduce drivers
         */
        CategoryMapper mapper = new CategoryMapper();
        CategoryReducer reducer = new CategoryReducer();
        mapDriver = new MapDriver<LongWritable, Text, Text, DoubleWritable>();
        mapDriver.setMapper(mapper);
        reduceDriver = new ReduceDriver<Text, DoubleWritable, Text, DoubleWritable>();
        reduceDriver.setReducer(reducer);
        mapReduceDriver = new MapReduceDriver<LongWritable, Text, Text, DoubleWritable, Text, DoubleWritable>();
        mapReduceDriver.setMapper(mapper);
        mapReduceDriver.setReducer(reducer);
    }

    @Test
    public void testMapper() {
        Text value1 = new Text("2012-01-01\t09:00\tNew York\tMen's Clothing\t214.05\tAmex\n");
        //Text value2 = new Text("2012-01-01\t09:00\tBahamas\tMen's Clothing\t300\tAmex");

        mapDriver.withInput(new LongWritable(0), value1);
        //mapDriver.withInput(new LongWritable(1),value2);

        mapDriver.withOutput(new Text("Men's Clothing"), new DoubleWritable(214.05));
        //mapDriver.withOutput(new Text("Bahamas"), new DoubleWritable(300.0));

        mapDriver.runTest();
    }


    @Test
    public void testReducer() {
        List<DoubleWritable> values = new ArrayList<DoubleWritable>();
        values.add(new DoubleWritable(100.8));
        values.add(new DoubleWritable(255));
        reduceDriver.withInput(new Text("Men's Clothing"), values);
        reduceDriver.withOutput(new Text("Men's Clothing"), new DoubleWritable(355.8));
        reduceDriver.runTest();
    }

    @Test
    public void testMapReduce() {
        Text value1 = new Text("2012-01-01\t09:00\tNew York\tMen's Clothing\t214.05\tAmex\n");
        Text value2 = new Text("2012-01-01\t09:00\tBahamas\tMen's Clothing\t300\tAmex");
        Text value3 = new Text("2012-01-01\t09:00\tNew York\tMen's Clothing\t250\tAmex\n");
        Text value4 = new Text("2012-01-01\t09:00\tNew York\tToys\t250\tAmex\n");
        Text value5 = new Text("2012-01-01\t09:00\tNew York\tToys\t300\tAmex\n");
        mapReduceDriver.addInput(new LongWritable(0), value1);
        mapReduceDriver.addInput(new LongWritable(1), value2);
        mapReduceDriver.addInput(new LongWritable(2), value3);
        mapReduceDriver.addInput(new LongWritable(3), value4);
        mapReduceDriver.addInput(new LongWritable(4), value5);
        mapReduceDriver.addOutput(new Text("Men's Clothing"), new DoubleWritable(764.05));
        mapReduceDriver.addOutput(new Text("Toys"), new DoubleWritable((550)));
        mapReduceDriver.runTest();

    }

}
