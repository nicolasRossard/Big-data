package salemax;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class SaleMaxDriver extends Configured implements Tool {
    public int run(String[] args) throws Exception {
        /*
         * Validate that two arguments were passed from the command line.
         */
        if (args.length != 2) {
            System.out.println("Usage: [input] [output]");
            System.exit(-1);
        }

        /*
         * Instantiate a Job object for your job's configuration.
         * Specify an easily-decipherable name for the job.
         */
        Job job = Job.getInstance(getConf());
        job.setJobName("Sale max per shop");

        /*
         * Specify the jar file that contains your driver, mapper, and reducer.
         * Hadoop will transfer this jar file to nodes in your cluster running
         * mapper and reducer tasks.
         */
        job.setJarByClass(SaleMaxDriver.class);
        job.setMapperClass(SaleMaxMapper.class);
        job.setReducerClass(SaleMaxReducer.class);

        /*
         * Define output tuple
         */
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        /*
         * Define input/output format to use for the job
         */
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        /*
         * Save paths
         */
        Path inputFilePath = new Path(args[0]);
        Path outputFilePath = new Path(args[1]);

        /*
         * Allow recursive
         */
        FileInputFormat.setInputDirRecursive(job, true);
        /*
         * Configure input/output file
         */
        FileInputFormat.addInputPath(job, inputFilePath);
        FileOutputFormat.setOutputPath(job, outputFilePath);
        FileSystem fs = FileSystem.newInstance(getConf());

        /*
         * if output file already exists it will delete it
         */
        if (fs.exists(outputFilePath)) {
            fs.delete(outputFilePath, true);
        }

        /*
         * Start the MapReduce job and wait for it to finish.
         * If it finishes successfully, return 0. If not, return 1.
         */
        return job.waitForCompletion(true) ? 0: 1;
    }

}