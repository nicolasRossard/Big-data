package category;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.StringTokenizer;
public class CategoryMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
    //public static final Log log = LogFactory.getLog(WordCountMapper.class);
    private final static DoubleWritable price = new DoubleWritable();
    private Text product = new Text();

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        //System.out.println(line);
        /*
         * Use Delimiter to separate tokens
         */
        StringTokenizer tokenizer = new StringTokenizer(line,"\t");
        /*
         * Check nb of tokens = 6
         */
        if (tokenizer.countTokens() != 6){
            //System.out.println("Erreur");
            //System.out.println(tokenizer.countTokens());
            return;
        }
        int i = 0;

        /* Index of datas for each line
         * 0 date 1 time 2 store 3 product 4 product cost 5 payment
         */
        while (tokenizer.hasMoreTokens()){
            switch(i){
                case 3:
                    product.set(tokenizer.nextToken());
                    break;
                case 4:
                    price.set(Double.parseDouble(tokenizer.nextToken()));
                    break;
                default:
                    tokenizer.nextToken();
                    break;
            }
            i++;
        }
        /*
         * Write Results
         */
        context.write(product, price);
    }

    public void run(Context context) throws IOException, InterruptedException {
        setup(context);
        //System.out.println("-------------------- MAPPER ----------------------");
        while (context.nextKeyValue()) {
            map(context.getCurrentKey(), context.getCurrentValue(), context);
        }
        cleanup(context);
        //System.out.println("--------------------------------------------------");

    }

}
/* I find this code on internet:
 * String line = value.ToString();
 * String[] singleShopData = line.split("\t");
 * shop.set(singleShopData[2]);
 * price.set(new DoubleWritable(singleShopData[4]);
 * context.write(shop,price);
 */