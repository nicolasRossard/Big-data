package total;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.Iterator;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

public class SalesTotalReducer extends Reducer<Text, DoubleWritable, IntWritable, DoubleWritable> {
    //public static final Log log = LogFactory.getLog(WordCountMapper.class);

    private DoubleWritable salesTotal = new DoubleWritable();
    private IntWritable salesCount = new IntWritable();

    @Override
    public void reduce(final Text key, final Iterable<DoubleWritable> values,
                       final Context context) throws IOException, InterruptedException {
        //System.out.println("-------------------- Reducer ----------------------");
        double sum = 0;
        double price = 0;
        int count = 0;
        Iterator<DoubleWritable> iterator = values.iterator();
        while (iterator.hasNext()) {

            price = iterator.next().get();
            sum += price;
            count +=1;
            //System.out.println("key: "+key+"\tprice = "+price+"\tTotal = "+sum +
            //       "\tNb of sales: " + count);
        }
        salesTotal.set(sum);
        salesCount.set(count);
        context.write(salesCount, salesTotal);
        //context.write(keyRes, salesTotal);
        //System.out.println(" keyRes " + keyRes + "\tSales = " +salesTotal);

        //System.out.println("--------------------------------------------------");

    }
}