/* args 0 input file path
 * args 1 output file path
 * args 2 : 1: Run category     2: run salemax     3:run total
 */

import category.CategoryDriver;
import org.apache.hadoop.util.ToolRunner;
import salemax.SaleMaxDriver;
import total.SalesTotalDriver;

public class RunClass {
    public static void main(String[] args) throws Exception {
        System.out.println("************************ Running Process ************************");
        System.out.println("***** Args:\t"+args[0] +"\t"+args[1]+"\t"+args[2]);
        String[] arguments={args[0],args[1]};
        System.out.print("***** Driver : ");
        int res = -1;
        switch(Integer.parseInt(args[2])){
            case 1:
                System.out.println("\tCategoryDriver\tInfo: Sales per category of products");
                CategoryDriver categoryDriver = new CategoryDriver();
                res = ToolRunner.run(categoryDriver, arguments);
                System.exit(res);
                break;
            case 2:
                System.out.println("\tSaleMaxDriver\tInfo: Best sale per store");
                SaleMaxDriver salesMaxDriver = new SaleMaxDriver();
                res = ToolRunner.run(salesMaxDriver, arguments);
                System.exit(res);
                break;
            case 3:
                System.out.println("\tSalesTotalDriver\tInfo: Total sales");
                SalesTotalDriver salesTotalDriver = new SalesTotalDriver();
                res = ToolRunner.run(salesTotalDriver, arguments);
                break;
            default:
                System.out.println("Erreur RunClass args");

                break;
        }
        System.out.println("***** exit code : "+res);
        System.out.println("*****************************************************************");
        System.exit(res);

    }
}
