package wordcount;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.util.Iterator;

public class WordCountReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
    //public static final Log log = LogFactory.getLog(WordCountMapper.class);

    private DoubleWritable salesTotal = new DoubleWritable();

    @Override
    public void reduce(final Text key, final Iterable<DoubleWritable> values,
                       final Context context) throws IOException, InterruptedException {
        //System.out.println("-------------------- Reducer ----------------------");
        double sum = 0;
        Iterator<DoubleWritable> iterator = values.iterator();
        //System.out.println(iterator.toString());
        while (iterator.hasNext()) {
            sum += iterator.next().get();
        }
        salesTotal.set(sum);
        //System.out.println(key + "\t" + sum);
        //log.info("RED key:" + key + " Sum : " + sum);

        context.write(key, salesTotal);
        //System.out.println("--------------------------------------------------");

    }
}