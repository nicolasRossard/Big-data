package wordcount;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.StringTokenizer;
public class WordCountMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
    //public static final Log log = LogFactory.getLog(WordCountMapper.class);
    private final static DoubleWritable price = new DoubleWritable();
    private Text shop = new Text();

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        //System.out.println(line);
        /*
         * Use Delimiter to separate tokens
         */
        StringTokenizer tokenizer = new StringTokenizer(line,"\t");
        /*
         * Check nb of tokens = 6
         */
        if (tokenizer.countTokens() != 6){
            //System.out.println("Erreur");
            //System.out.println(tokenizer.countTokens());
            return;
        }
        /*
         * Loop all elements of the line
         * For now we use only two datas but maybe we will use more later
         */
        int i = 0;
        while (tokenizer.hasMoreTokens()){
            switch(i){
                case 2:
                    shop.set(tokenizer.nextToken());
                    break;
                case 4:
                    price.set(Double.parseDouble(tokenizer.nextToken()));
                    break;
                default:
                    tokenizer.nextToken();
                    break;
            }
            i++;
        }
        /*
         * Write Results
         */
        //System.out.println("Shop: " + shop +"\tprice: " +price);
        //log.info("Map Key" + shop + "\tprice: " + price);
        context.write(shop, price);
    }

    public void run(Context context) throws IOException, InterruptedException {
        setup(context);
        //System.out.println("-------------------- MAPPER ----------------------");
        while (context.nextKeyValue()) {
            map(context.getCurrentKey(), context.getCurrentValue(), context);
        }
        cleanup(context);
        //System.out.println("--------------------------------------------------");

    }

}
/* I find this code on internet:
 * String line = value.ToString();
 * String[] singleShopData = line.split("\t");
 * shop.set(singleShopData[2]);
 * price.set(new DoubleWritable(singleShopData[4]);
 * context.write(shop,price);
 */